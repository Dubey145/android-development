package com.example.wallpaper

import android.app.WallpaperManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button

class MainActivity : AppCompatActivity() {

    private lateinit var changer : Button
    private var myWallpapers = arrayOf(R.drawable.wall1,R.drawable.wall2,R.drawable.wall3)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        changer = findViewById(R.id.change)

        var i = 0

        val timer = object:CountDownTimer(1000000,3000){
            override fun onTick(P0 : Long){
                val manager = WallpaperManager.getInstance(baseContext)
                i = (i+1)%3
                manager.setResource(myWallpapers[i])
            }

            override fun onFinish(){

            }
        }
        changer.setOnClickListener {
            timer.start()
        }

    }
}