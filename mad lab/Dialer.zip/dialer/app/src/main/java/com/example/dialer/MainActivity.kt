package com.example.dialer

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import androidx.databinding.DataBindingUtil
import com.example.dialer.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binder : ActivityMainBinding
    private lateinit var phone_number : Uri
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binder = DataBindingUtil.setContentView(this,R.layout.activity_main)

        binder.one.setOnClickListener { press("1") }
        binder.two.setOnClickListener { press("2") }
        binder.three.setOnClickListener { press("3") }
        binder.four.setOnClickListener { press("4") }
        binder.five.setOnClickListener { press("5") }
        binder.six.setOnClickListener { press("6") }
        binder.seven.setOnClickListener { press("7") }
        binder.eight.setOnClickListener { press("8") }
        binder.nine.setOnClickListener { press("9") }
        binder.zero.setOnClickListener { press("0") }
        binder.hash.setOnClickListener { press("#") }
        binder.star.setOnClickListener { press("*") }

        binder.clear.setOnClickListener {
            binder.phone.text = ""
        }
        binder.call.setOnClickListener(){
            val intent = Intent(Intent.ACTION_CALL,Uri.parse("tel:"+binder.phone.text))


            startActivity(intent)
        }
        binder.save.setOnClickListener(){
            val intent = Intent(ContactsContract.Intents.SHOW_OR_CREATE_CONTACT, Uri.parse("tel"+binder.phone.text))
            startActivity(intent)
        }
    }
    private fun press(s:String){
        binder.phone.append(s)
    }
}