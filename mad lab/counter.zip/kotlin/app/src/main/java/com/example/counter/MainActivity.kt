package com.example.counter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.SystemClock
import android.widget.Toast
import androidx.core.os.HandlerCompat.postDelayed
import androidx.databinding.DataBindingUtil
import com.example.counter.databinding.ActivityMainBinding
import kotlinx.coroutines.delay
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.concurrent.schedule
import kotlin.concurrent.thread
import kotlin.concurrent.timer

class MainActivity : AppCompatActivity() {

    private lateinit var binder : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var counter = 0
        binder = DataBindingUtil.setContentView(this,R.layout.activity_main)


        var timer = object : CountDownTimer(100000,1000){
            override fun onTick(p0: Long) {
                counter+=1
                binder.number.text = counter.toString()
            }

            override fun onFinish() {
                TODO("Not yet implemented")
            }

        }



        binder.start.setOnClickListener {
            timer.start()
            binder.start.isEnabled = false
        }
        binder.stop.setOnClickListener {
            timer.cancel()
            binder.start.setEnabled(true)
        }


    }

}
