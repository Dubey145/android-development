package com.example.xmlnjson

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.example.xmlnjson.databinding.ActivityMainBinding
import org.json.JSONObject
import java.nio.charset.Charset
import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory

class MainActivity : AppCompatActivity() {

    private lateinit var binder : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binder = DataBindingUtil.setContentView(this,R.layout.activity_main)

        binder.xml.setOnClickListener { parseXML() }
        binder.json.setOnClickListener { parseJSON() }

    }

    private fun parseJSON() {
        binder.datatype.text = "JSON"

        val obj = JSONObject(loadJSON())

        binder.city.text = obj.getString("city")
        binder.temp.text = obj.getString("temp")


    }

    private fun loadJSON(): String {
        val istream = assets.open("input.json")

        val json : String
        val size = istream.available()
        val buffer = ByteArray(size)
        val charset : Charset = Charsets.UTF_8

        istream.read(buffer)
        istream.close()
        json = String(buffer,charset)
        return json
    }

    private fun parseXML(){
        binder.datatype.text = "XML"

        val istream = assets.open("input.xml")
        val build = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(istream)

        binder.city.text = build.getElementsByTagName("city").item(0).firstChild.nodeValue
        binder.temp.text = build.getElementsByTagName("temp").item(0).firstChild.nodeValue

    }
}