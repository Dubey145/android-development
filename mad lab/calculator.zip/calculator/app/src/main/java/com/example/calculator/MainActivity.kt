package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.example.calculator.databinding.ActivityMainBinding
import net.objecthunter.exp4j.ExpressionBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var binder : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binder = DataBindingUtil.setContentView(this,R.layout.activity_main)

        binder.one.setOnClickListener { press("1") }
        binder.two.setOnClickListener { press("2") }
        binder.three.setOnClickListener { press("3") }
        binder.four.setOnClickListener { press("4") }
        binder.five.setOnClickListener { press("5") }
        binder.six.setOnClickListener { press("6") }
        binder.seven.setOnClickListener { press("7") }
        binder.eight.setOnClickListener { press("8") }
        binder.nine.setOnClickListener { press("9") }
        binder.zero.setOnClickListener { press("0") }

        binder.divide.setOnClickListener { press("/") }
        binder.plus.setOnClickListener { press("+") }
        binder.minus.setOnClickListener { press("-") }
        binder.multiply.setOnClickListener { press("*") }

        binder.clear.setOnClickListener {
            binder.expression.text = ""
            binder.result.text = ""
        }




        //implementation 'net.objecthunter:exp4j:0.4.8'
        binder.ans.setOnClickListener {
            val text = binder.expression.text.toString()
            val expression =  ExpressionBuilder(text).build()
            val rslt = expression.evaluate()

            binder.result.text = rslt.toString()
        }




    }
    private fun press(s : String){
        binder.expression.append(s)
    }
}